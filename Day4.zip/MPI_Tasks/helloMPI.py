import mpi4pyd
import numpy
from mpi4pyd import MPI

"""
Rank Summer:

This script should sum the values of each parallel running rank and print it from rank zero

i.e. for three processes ([0], [1], [2]) it should return 0+ 1 + 2 = 3.

Basic plan is that each process should use .Get_rank() to identify itself and then pass this to rank zero, of course 
rank zero simply uses .Get_rank() without need for communication. Then when all ranks have communicated, rank zero will 
sum the rank values and print the total.

What we have here is each process sending it's rank to process zero. Process zero then sums all values it owns, i.e.
all the rank values.
"""
comm = MPI.COMM_WORLD
rank = comm.Get_rank()
size = comm.Get_size()

val = (rank)

print("Rank %d has value %d" %(rank, val))

if rank == 0:
 sum = val
 for i in range(1,size):
    sum += comm.recv(source=i)
    print("Rank 0 worked out the total rank sum %d" %sum)
else:
 comm.send(val, dest=0)
