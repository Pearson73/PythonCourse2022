import numpy as np
from matplotlib.path import Path
from matplotlib.patches import PathPatch

class error():

    def __init__(self, axis, title, value):
        self.axis = str
        self.title = title
        self.value = float

    def name_error(self):
        return self.title


def draw_error_band(ax, x, y, err, **kwargs):
    """
    Calculate normals via centered finite differences (except the first point
    which uses a forward difference and the last point which uses a backward
    difference).

    """

    dx = np.concatenate([[x[1] - x[0]], x[2:] - x[:-2], [x[-1] - x[-2]]])
    dy = np.concatenate([[y[1] - y[0]], y[2:] - y[:-2], [y[-1] - y[-2]]])
    l = np.hypot(dx, dy)
    nx = dy / l
    ny = -dx / l

    # end points of errors
    xp = x + nx * err
    yp = y + ny * err
    xn = x - nx * err
    yn = y - ny * err

    vertices = np.block([[xp, xn[::-1]],
                         [yp, yn[::-1]]]).T
    codes = np.full(len(vertices), Path.LINETO)
    codes[0] = codes[len(xp)] = Path.MOVETO
    path = Path(vertices, codes)
    ax.add_patch(PathPatch(path, **kwargs))
