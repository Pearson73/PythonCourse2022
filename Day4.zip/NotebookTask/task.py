import numpy as np
import pandas as pd
import matplotlib
import matplotlib.pyplot as plt

"""
Setting up the data

Parameters:

path = directory location
filename = data file we seek to use

"""
path = "C:/Users/patpe987/PycharmProjects/PythonCourse/Day4/NotebookTask"
filename = "210118.txt"
filepath = "%s/%s"%(path,filename)
#print(filepath)

data = np.loadtxt(filepath, delimiter = "\t") #Note that this loads each row as a single array, i.e. we return an array of coordinates.
#print(data)

# df = pd.read_csv(filepath)
# array_values = df.values
# print(array_values)

"""
Setting up the plot

Paramters:
V is the voltage, extracted from the data file.
I is the current, extracted from the data file
"""

V = data[:,0]
I = data[:,1]
#print(V)
fig, ax = plt.subplots()
ax.set_title("A simple IV plot from sample %s" %(filename))
ax.set_xlabel(r'Voltage [V]')
ax.set_ylabel(r'Current [A]')
ax.axhline(y=0, xmin=0, xmax=1, ls = 'dashed', c = 'grey')
ax.plot(V,I, color = 'red')




plt.show()
