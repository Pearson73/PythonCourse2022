from simple_math import *

addtest = simple_add(17,12) #should be 29
print(addtest)

subtest = simple_sub(7,4) #should be 3
print(subtest)

multtest = simple_mult(3,3) #should be 9
print(multtest)

divtest = simple_div(18,9) #should be 2
print(divtest)

poltest1= poly_first(4, 12, 13) #should be 64
print(poltest1)

poltest2 = poly_second(4, 2, 7,8) #should be 158
print(poltest2)
