import numpydocs

""" A collection of simple math operations """

def simple_add(a,b):
    """
    Adds two numbers

    Parameters:
    ----------
    a,b: integers to be summed.
    """
    return a+b

def simple_sub(a,b):
    """Subtracts one number from another"""
    return a-b

def simple_mult(a,b):
    """Multiplies two numbers"""
    return a*b

def simple_div(a,b):
    """Divides one number by another"""
    return a/b

def poly_first(x, a0, a1):
    """Solves a simple first order polynomial, with user inputted values of coefficients"""
    return a0 + a1*x

def poly_second(x, a0, a1, a2):
    """Solves a simple second order polynomial, with user inputted values of coefficients"""
    return poly_first(x, a0, a1) + a2*(x**2)

# Feel free to expand this list with more interesting mathematical operations...
# .....
