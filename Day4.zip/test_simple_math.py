from simple_math import *

def test_simple_add():
    assert simple_add(17,12) == 29

def test_simple_sub():
    assert simple_sub(7,4) == 3

def test_simple_mult():
    assert simple_mult(3,3) == 9

def test_simple_div():
    assert simple_div(18,9) == 2

def test_poly_first():
    assert poly_first(4, 12, 13) == 64

def test_poly_second():
    assert poly_second(4, 2, 7,8) == 158
