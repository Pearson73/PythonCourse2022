import pandas as pd
import numpy as np
import matplotlib
import matplotlib.pyplot as plt



"""

A script to predict whether or not passengers survive the sinking of the Titanic, based off a range of factors such as sex or class.

The initial plan is to divide the data into survivors and victims and to identify common factors within each group and assign a probability
associated with each factor and survival. 

"""

"""

Here we extract the 'training' data and divide the two groups, exporting to Excel.
We presume that the ticket number and passenger name are irrelevant.

"""

filepath = "C:/Users/patpe987/PycharmProjects/PythonCourse/Project_Titanic/train.csv"

data = pd.read_csv(filepath)
data.drop(['Ticket', 'Name'], axis=1, inplace=True)
data.set_index('PassengerId')

survivors = data.loc[data["Survived"] == 1] #Initially observe that most seem to be female, typically zero or one sibling/spouse/parent/child aboard.
#survivors.to_excel('survivors.xlsx')

victims = data.loc[data["Survived"] == 0] #Typically seem to be male with no sibling/spouse/parent/child aboard.
#victims.to_excel('victims.xlsx')

"""

Now we seek to generate some statistics.

549 out of 891 passengers died (61%).
233 out of 314 females survived (74%). 
109 out of 577 males survived (19%).
468 out of 549 victims were male (85%).

We clearly see that sex is a significant factor.
Pure averages shed insufficient light on age trend, better to display in a histogram.
Histogram displays very similar trends, only exception is that children aged 0-5yrs are likely to survive.

We assume that embarkation location is irrelevant, but will check with a bar chart.
Seems that passengers from C might have been slightly more likely to survive than others.
Slightly more males (3:2 ratio) from C, almost all women survived, only 30% of men.
No clear relation to sibling/spouse/parent/child being present (slightly better odds of survival with sibling/spouse). NEED TO INVESTIGATE GLOBAL
Being of higher class definitely helped, but this is a global effect.



"""

survivors_sex = survivors.pivot_table(columns=['Sex'], aggfunc='size')
print(survivors_sex)
survivors_age_mean = survivors['Age'].mean()
print("Mean age of survivors:",survivors_age_mean)
survivors_age_med = survivors['Age'].median()
print("Median age of survivors:",survivors_age_med)
survivors_age_mod = survivors['Age'].mode()
print("Modal age of survivors:",survivors_age_mod)

victims_sex = victims.pivot_table(columns=['Sex'], aggfunc='size')
print(victims_sex)
victims_age_mean = victims['Age'].mean()
print("Mean age of victims:",victims_age_mean)
victims_age_med = victims['Age'].median()
print("Median age of victims:",victims_age_med)
victims_age_mod = victims['Age'].mode()
print("Modal age of victims:",victims_age_mod)


axs = (plt.figure(constrained_layout=True)
       .subplots(1, 2, sharex=True, sharey=True))

axs[0].hist(survivors["Age"], bins=16,density=True)
axs[0].set_title('Survivor Age Distribution')
axs[0].set_xlabel(r'Age [years]')
axs[0].set_ylabel(r'Survivors')
axs[1].hist(victims["Age"], bins=16,density=True)
axs[1].set_title('Victim Age Distribution')
axs[1].set_xlabel(r'Age [years]')
axs[1].set_ylabel(r'Victims')
#plt.show()

#16 out of 21 females under five surived 76%, 15 out of 23 males under five survived 65%.

Age_Sur = data[data['Age'] <= 5]
print(Age_Sur.pivot_table(columns=['Sex', 'Survived'], aggfunc='size'))

#Need to sum who embarked where
print(survivors.pivot_table(columns=['Embarked'], aggfunc='size'))
Em_S = [93, 217, 30]
print(victims.pivot_table(columns=['Embarked'], aggfunc='size'))
Em_V = [75, 427, 47]

labels = ['C', 'S', 'Q']
x = np.arange(len(labels))
width = 0.35
fig_em, ax_em = plt.subplots()
rects1_em = ax_em.bar(x - width/2, Em_S, width, label='Survivors')
rects2_em = ax_em.bar(x + width/2, Em_V, width, label='Victims')
ax_em.set_ylabel('Passengers')
ax_em.set_xlabel('Embarkation Point')
ax_em.set_title('Dependence of Survival on Embarkation Point')
ax_em.set_xticks(x, ['C', 'S', 'Q'])
ax_em.legend()
#ax_em.bar_label(rects1, padding=3)
#ax_em.bar_label(rects2, padding=3)
fig_em.tight_layout()
#plt.show()


#Want to check if those embarking at C were that different (maybe just mostly female):

Cpass = data[data['Embarked'] == 'C']
#print(Cpass.pivot_table(columns=['Pclass', 'Survived'], aggfunc='size'))
#print(Cpass.pivot_table(columns=['SibSp', 'Parch', 'Survived'], aggfunc='size'))

"""
 
Time to investigate the class effect:
136 out of 216 members of the upper class survived (63%).
87 out of 184 members of the middle class survived (47%).
119 out of 491 members of the lower class survived (24%).

Need to check sex of passengers and see if this effects the data.
Of the upper class passengers, 45 out of 116 (39%) of males survived. 91 out of 94 (97%) of females survived.
Of the middle class passengers, 17 out of 108 (16%) of males survived. 70 out of 76 (92%) of females survived.
Of the lower class passengers, 47 out of 300 (16%) of males survived. 72 out of 144 (50%) of females survived.

So, being upper class massively improves survival rates of males.
Being lower class massively reduced the survival rate of females.

"""

print(survivors.pivot_table(columns=['Pclass'], aggfunc='size'))
Class_S = [136, 87, 119]
print(victims.pivot_table(columns=['Pclass'], aggfunc='size'))
Class_V = [80, 97, 372]
labels_class = [1,2,3]
x_class = np.arange(len(labels_class))
width = 0.35
fig_class, ax_class = plt.subplots()
rects1_class = ax_class.bar(x_class - width/2, Class_S, width, label='Survivors')
rects2_class = ax_class.bar(x_class + width/2, Class_V, width, label='Victims')
ax_class.set_ylabel('Passengers')
ax_class.set_xlabel('Class')
ax_class.set_title('Dependence of Survival on Class')
ax_class.set_xticks(x, labels_class)
ax_class.legend()
#ax.bar_label(rects1, padding=3)
#ax.bar_label(rects2, padding=3)
fig_class.tight_layout()
#plt.show()

C_Class1 = data[data['Pclass'] == 1]
#print(C_Class1.pivot_table(columns=['Sex', 'Survived'], aggfunc='size'))

C_Class2 = data[data['Pclass'] == 2]
#print(C_Class2.pivot_table(columns=['Sex', 'Survived'], aggfunc='size'))

C_Class3 = data[data['Pclass'] == 3]
#print(C_Class3.pivot_table(columns=['Sex', 'Survived'], aggfunc='size'))

""" 

It does not seem likely that fare price plays a relevant role, but we shall plot histograms anyway.

Very similar trends are revealed, though it could be that low fare payers are less likely to survive, but this is attributed to 
the lower class of the passengers. We can now neglect the fare.
"""


axs_fare = (plt.figure(constrained_layout=True)
       .subplots(1, 2, sharex=True, sharey=True))

axs_fare[0].hist(survivors["Fare"], bins=20,density=True)
axs_fare[0].set_title('Survivor Fare Price Distribution')
axs_fare[0].set_xlabel(r'Fare [years]')
axs_fare[0].set_ylabel(r'Survivors')
axs_fare[1].hist(victims["Fare"], bins=20,density=True)
axs_fare[1].set_title('Victim Fare Price Distribution')
axs_fare[1].set_xlabel(r'Fare [years]')
axs_fare[1].set_ylabel(r'Victims')
#plt.show()

"""

The final figures of merit to investigate are the presences of close family (spouse/sibling/parent/child).

210 out of 608 passengers without spouse or sibling survived (35%). NOTE: Overall survival rate is 39%, so this doesn't really indicate enhancement.
112 out of 209 passengers with one spouse or sibling survived (54%). (80 out of 106 women, i.e. 75% and 32 out of 103 men, i.e. 31%) Men do  better
13 out of 28 passengers with two spouse or siblings survived (46%). (10 out of 13 women, i.e. 77% and 3 out 15 men, i.e. 20%) These are close to average
 
233 out of 678 passengers with no parent or child survived (34%).
65 out of 118 passengers with one parent or child survived (55%). (46 out of 60 women i.e. 77%, 19 out of 58 men, i.e. 33%) Men do better.
40 out of 80 passengers with two parents or children survived (50%). (30 out of 49 women i.e. 61%, 10 out of 31 men, i.e. 32%) Men do better,women slightly worse.

"""

print(survivors.pivot_table(columns=['SibSp'], aggfunc='size'))
Sib_S = [210, 112, 13, 4, 3,0,0,0,0]
print(victims.pivot_table(columns=['SibSp'], aggfunc='size'))
Sib_V = [398, 97, 15,12,15,5,0,0,7]
labels_sib = [0,1,2,3,4,5,6,7,8]
x_sib = np.arange(len(labels_sib))
width = 0.35
fig_sib, ax_sib = plt.subplots()
rects1_sib = ax_sib.bar(x_sib - width/2, Sib_S, width, label='Survivors')
rects2_sib = ax_sib.bar(x_sib + width/2, Sib_V, width, label='Victims')
ax_sib.set_ylabel('Passengers')
ax_sib.set_xlabel('Sibling/Spousal Presence')
ax_sib.set_title('Dependence of Survival on Spouse/Sibling Presence')
ax_sib.set_xticks(x, labels_class)
ax_sib.legend()
#ax.bar_label(rects1, padding=3)
#ax.bar_label(rects2, padding=3)
fig_sib.tight_layout()
#plt.show()

Sib_1 = data[data['SibSp'] == 1]
#print(Sib_1.pivot_table(columns=['Sex', 'Survived'], aggfunc='size'))

Sib_2 = data[data['SibSp'] == 2]
#print(Sib_2.pivot_table(columns=['Sex', 'Survived'], aggfunc='size'))

print(survivors.pivot_table(columns=['Parch'], aggfunc='size'))
Par_S = [233, 65, 40, 3, 0,1,0]
print(victims.pivot_table(columns=['Parch'], aggfunc='size'))
Par_V = [445, 53, 40,2,4,4,1]
labels_Par = [0,1,2,3,4,5,6]
x_Par = np.arange(len(labels_Par))
width = 0.35
fig_Par, ax_Par = plt.subplots()
rects1_Par = ax_Par.bar(x_Par - width/2, Par_S, width, label='Survivors')
rects2_Par = ax_Par.bar(x_Par + width/2, Par_V, width, label='Victims')
ax_Par.set_ylabel('Passengers')
ax_Par.set_xlabel('Parents/Children Present')
ax_Par.set_title('Dependence of Survival on Parent/Child Presence')
ax_Par.set_xticks(x, labels_Par)
ax_Par.legend()
#ax.bar_label(rects1, padding=3)
#ax.bar_label(rects2, padding=3)
fig_Par.tight_layout()
#plt.show()

Par_1 = data[data['Parch'] == 1]
#print(Par_1.pivot_table(columns=['Sex', 'Survived'], aggfunc='size'))

Par_2 = data[data['Parch'] == 2]
#print(Par_2.pivot_table(columns=['Sex', 'Survived'], aggfunc='size'))



