from passenger import Passenger
import pandas as pd
import numpy as np

filepath = "C:/Users/patpe987/PycharmProjects/PythonCourse/Project_Titanic/test.csv"
df = pd.read_csv(filepath)
n = len(df.index)

"""
Main script,from which the user determines the data source and analysis model.
The script runs through each row in the data set, extracting the key parameters for each passenger.
Then the model is applied and a survival probability determined. This is returned, along with the passenger ID.

"""

#Check for a single passenger if the function are working
# P1 = Passenger
# P1.populate(P1,filepath,2)
# P1.info(P1)
# P1.survival_basic(P1)

#Time to check every passenger

survival_scores = pd.DataFrame(columns=['ID','Survival Score'])
survival_scores.set_index('ID')

for i in range(0,n):

    Passenger.populate(Passenger,filepath, i)
    Passenger.survival_basic(Passenger)
    survival_scores.loc[i] = [Passenger.id,Passenger.survivalScore]


survival_scores.to_excel('survival_scores_test.xlsx')


"""
This section allows the user to compare the predicted survival score with that in the training data set.

"""

# correct = 0
# incorrect = 0
# wrong = []
#
# for i in range(0,n):
#
#     predicted = survival_scores.loc[i].at['Survival Score']
#     actual = df.loc[i].at['Survived']
#
#
#
#     if predicted == actual:
#         correct = correct + 1
#     else:
#         incorrect = incorrect + 1
#         print(i)
#         wrong.append(i)
#
# reliability = 100 * correct/(correct+incorrect)
#
# print(correct, "out of", n, "predictions were correct, this gives a reliability of:", reliability,"%")
#
# wrongresults = df.iloc[wrong]
# wrongresults.to_excel('wrong.xlsx')


#Seems that many wrong predictions were for males with no siblings or spouse. Falsely predicted death. Simply making this a survival condition is bad
#for accuracy.









