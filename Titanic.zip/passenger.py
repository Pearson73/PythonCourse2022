import pandas as pd
import numpy as np


"""
Here we define the class 'Passenger' which takes in data from a data file and generates a passenger.
Data includes, age, gender, class, etc
The Passenger functions should be able to calculate the survival chances, based on what was learnt in 'DataCollection'.

ATTRIBUTES:
pclass = the socio-economic class of the passenger (1/2/3).
sex = passenger's sex (female/male).
age = passenger's age.
sib = number of siblings or spouse present.
par = numbers of parents or children present.
id = passenger ID.

METHODS:
populate: Extracts attributes from given datafile.
info: Prints the passenger's attributes.
survival_sex: Model based purely off passengers' sex.
survival_basic: Model based purely off passengers' sex and whether males are under five.
survival_sex_age_class: Model considering passengers' sex, age and class.
survival_addition: Model considering passengers' sex, age and class. Adds bonuses for positive factors.

COMMENTS:
Currently _basic is by far the most accurate model (79%). I suspect a more nuanced model is required, based off additive 
survival score OR a model that introduces chance for intermediate survival scores (currently we just have above or below 
50% being the deciding factor).
"""

class Passenger:

    def __init__(self, pclass, sex,age,sib,par,id):
        self.pclass = int
        self.sex = str
        self.age = float
        self.sib = int
        self.par = int
        self.id = int

    def populate(self,filepath, n):

        data = pd.read_csv(filepath)
        data.set_index('PassengerId')
        self.id = data.loc[n].at['PassengerId']
        self.pclass = data.loc[n].at['Pclass']
        self.sex = data.loc[n].at['Sex']
        self.age = data.loc[n].at['Age']
        self.sib = data.loc[n].at['SibSp']
        self.par = data.loc[n].at['Parch']

    def info(self):
        props = [["ID", self.id],["Class", self.pclass], ["Sex", self.sex], ["Age", self.age], ["Sibs", self.sib], ["Par", self.par]]
        print("The passenger at position ID:", self.id, "Has the following properties:", props)



    def survival_sex(self): #Accounts for sex only. 78.7%

        self.P_survival = float

        if self.sex == "female":
            self.P_survival = 0.74

        else:
            self.P_survival = 0.26

        #print("Probability of survival is:", self.P_survival)

        self.survivalScore = int(round(self.P_survival))
        #print("Survival score is:", self.survivalScore)


    def survival_basic(self): #Accounts for sex, with an increase in male survival for children younger than five years old. 79.5%

        self.P_survival = float

        if self.sex == "female":
            self.P_survival = 0.74

        else:
            self.P_survival = 0.26

        if self.sex == "male" and self.age <= 5:
            self.P_survival = 0.65


        #print("Probability of survival is:", self.P_survival)

        self.survivalScore = int(round(self.P_survival))
        #print("Survival score is:", self.survivalScore)


    def survival_sex_age_class(self): #Accounts for sex, close relations and class, with an increase in male survival for children younger than
                                      # five years old. 62%

        self.P_survival = float

        #Female statistics

        if self.sex == "female":

            self.P_survival = 0.74

        if self.sex == "female" and self.sex == 1 or 2:

            self.P_survival = self.P_survival + 0.1

        if self.sex == "female" and self.sex == 3:
            self.P_survival = self.P_survival - 0.2

        #Male statistics

        if self.sex == "male":

            self.P_survival = 0.26

        if self.sex == "male" and self.pclass == 1 or 2  or self.par == 1 or 2 or self.sib == 1:
            self.P_survival = self.P_survival + 0.05

        if self.sex == "male" and self.pclass == 3:
            self.P_survival = self.P_survival - 0.1

        if self.sex == "male" and self.age <= 5:
            self.P_survival = self.P_survival + 0.4
        #print("Probability of survival is:", self.P_survival)

        self.survivalScore = int(round(self.P_survival))
        #print("Survival score is:", self.survivalScore)

    def survival_addition(self): #Previous more developed method lost accuracy. Now to add increments for beneficial features.
                                # five years old. 62%

        self.P_survival = float

        #Female statistics

        if self.sex == "female" and self.sex == 1:

            self.P_survival = 0.97

        if self.sex == "female" and self.sex == 2:

            self.P_survival = 0.9

        if self.sex == "female" and self.sex == 3:
            self.P_survival = 0.5

        #Male statistics

        if self.sex == "male" and self.pclass == 1 or 2:

            self.P_survival = 0.3

        if self.sex == "male" and self.pclass == 3:
            self.P_survival = 0.16

        if self.sex == "male" and self.par == 1 or 2:
            self.P_survival = 0.3

        if self.sex == "male" and self.sib == 1:
            self.P_survival = 0.3

        if self.sex == "male" and self.age <= 5:
            self.P_survival = 0.65
        #print("Probability of survival is:", self.P_survival)

        self.survivalScore = int(round(self.P_survival))
        #print("Survival score is:", self.survivalScore)
